import csv
import os
import shutil
import uuid
from pathlib import Path

from fastapi import FastAPI, File, Form, Request, UploadFile
from fastapi.responses import RedirectResponse
from fastapi.staticfiles import StaticFiles
from starlette.middleware.sessions import SessionMiddleware
from starlette.templating import Jinja2Templates

from app.auth import authenticate_user, create_default_admin
from app.database import get_connection, init_db

UPLOAD_DIR = Path("uploads")
UPLOAD_DIR.mkdir(exist_ok=True)

app = FastAPI(title="GLA CRM Dashboard Platform")

secret_key = os.getenv("SECRET_KEY", "temporary-dev-secret-key")
app.add_middleware(SessionMiddleware, secret_key=secret_key)

templates = Jinja2Templates(directory="templates")

if Path("github-pages").exists():
    app.mount("/dashboard-files", StaticFiles(directory="github-pages", html=True), name="dashboard_files")


@app.on_event("startup")
def startup():
    init_db()
    create_default_admin()


def current_user(request: Request):
    return request.session.get("user")


def require_login(request: Request):
    user = current_user(request)
    if not user:
        return None
    return user


def count_csv_rows(path: Path):
    try:
        with path.open("r", encoding="utf-8-sig", newline="") as f:
            reader = csv.reader(f)
            rows = list(reader)
            if not rows:
                return 0
            return max(len(rows) - 1, 0)
    except Exception:
        return None


@app.get("/")
def root(request: Request):
    if current_user(request):
        return RedirectResponse("/admin", status_code=303)
    return RedirectResponse("/login", status_code=303)


@app.get("/login")
def login_page(request: Request):
    return templates.TemplateResponse(
        request=request,
        name="login.html",
        context={"error": None},
    )


@app.post("/login")
def login_submit(
    request: Request,
    username: str = Form(...),
    password: str = Form(...),
):
    user = authenticate_user(username, password)

    if not user:
        return templates.TemplateResponse(
            request=request,
            name="login.html",
            context={"error": "Invalid username or password."},
        )

    request.session["user"] = user
    return RedirectResponse("/admin", status_code=303)


@app.get("/logout")
def logout(request: Request):
    request.session.clear()
    return RedirectResponse("/login", status_code=303)


@app.get("/admin")
def admin(request: Request):
    user = require_login(request)
    if not user:
        return RedirectResponse("/login", status_code=303)

    conn = get_connection()
    cur = conn.cursor()

    upload_count = cur.execute("SELECT COUNT(*) AS count FROM uploads").fetchone()["count"]
    latest_uploads = cur.execute(
        "SELECT * FROM uploads ORDER BY uploaded_at DESC LIMIT 5"
    ).fetchall()

    conn.close()

    return templates.TemplateResponse(
        request=request,
        name="admin.html",
        context={
                        "user": user,
            "upload_count": upload_count,
            "latest_uploads": latest_uploads,
        },
    )


@app.get("/upload")
def upload_page(request: Request):
    user = require_login(request)
    if not user:
        return RedirectResponse("/login", status_code=303)

    upload_types = [
        "VRVH voter file",
        "purge list",
        "outreach/contact history",
        "registration apps",
        "zodiac data",
        "primary election data",
        "other",
    ]

    return templates.TemplateResponse(
        request=request,
        name="upload.html",
        context={"user": user, "upload_types": upload_types, "message": None},
    )


@app.post("/upload")
def upload_file(
    request: Request,
    upload_type: str = Form(...),
    file: UploadFile = File(...),
):
    user = require_login(request)
    if not user:
        return RedirectResponse("/login", status_code=303)

    original_filename = file.filename or "uploaded_file.csv"
    suffix = Path(original_filename).suffix.lower()

    if suffix not in [".csv", ".txt"]:
        upload_types = [
            "VRVH voter file",
            "purge list",
            "outreach/contact history",
            "registration apps",
            "zodiac data",
            "primary election data",
            "other",
        ]
        return templates.TemplateResponse(
            request=request,
            name="upload.html",
            context={
                                "user": user,
                "upload_types": upload_types,
                "message": "For this first version, please upload CSV files only.",
            },
        )

    stored_filename = f"{uuid.uuid4().hex}{suffix}"
    stored_path = UPLOAD_DIR / stored_filename

    with stored_path.open("wb") as buffer:
        shutil.copyfileobj(file.file, buffer)

    row_count = count_csv_rows(stored_path)

    conn = get_connection()
    cur = conn.cursor()
    cur.execute(
        """
        INSERT INTO uploads
        (original_filename, stored_filename, upload_type, uploaded_by, row_count, status)
        VALUES (?, ?, ?, ?, ?, ?)
        """,
        (
            original_filename,
            stored_filename,
            upload_type,
            user["username"],
            row_count,
            "uploaded",
        ),
    )
    conn.commit()
    conn.close()

    return RedirectResponse("/uploads", status_code=303)


@app.get("/uploads")
def uploads_page(request: Request):
    user = require_login(request)
    if not user:
        return RedirectResponse("/login", status_code=303)

    conn = get_connection()
    cur = conn.cursor()
    uploads = cur.execute(
        "SELECT * FROM uploads ORDER BY uploaded_at DESC"
    ).fetchall()
    conn.close()

    return templates.TemplateResponse(
        request=request,
        name="uploads.html",
        context={"user": user, "uploads": uploads},
    )


@app.get("/reports")
def reports_page(request: Request):
    user = require_login(request)
    if not user:
        return RedirectResponse("/login", status_code=303)

    reports = [
        "Contacted voters report",
        "Registration after outreach report",
        "Purge status report",
        "Returned to VRVH report",
        "County performance report",
        "Follow-up needed report",
    ]

    return templates.TemplateResponse(
        request=request,
        name="reports.html",
        context={"user": user, "reports": reports},
    )


@app.get("/dashboard")
def dashboard(request: Request):
    user = require_login(request)
    if not user:
        return RedirectResponse("/login", status_code=303)

    return RedirectResponse("/dashboard-files/index.html", status_code=303)
